BUILD BẰNG GITHUB ACTIONS
1. Tải Stockfish bản Android armv8 (Releases của Stockfish trên GitHub), giải nén, đổi tên file chạy thành libstockfish.so
2. Bỏ vào app/src/main/jniLibs/arm64-v8a/libstockfish.so
3. Up cả thư mục này lên 1 repo GitHub (nhớ cả thư mục .github)
4. Tab Actions -> Build APK -> tải ChessAssist-apk ở phần Artifacts
