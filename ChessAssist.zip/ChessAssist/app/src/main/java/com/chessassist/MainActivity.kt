package com.chessassist

import android.app.Activity
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(48, 96, 48, 48) }
        box.addView(TextView(this).apply {
            text = "1) Bấm Bắt đầu, cấp quyền overlay + quay màn hình\n2) Mở app cờ, kéo khung xanh vào bàn cờ (nút Dời)\n3) Ở thế cờ ban đầu bấm Học\n4) Bấm Gợi ý hoặc Live"
        })
        box.addView(Button(this).apply { text = "Bắt đầu"; setOnClickListener { start() } })
        setContentView(box)
    }

    private fun start() {
        if (!Settings.canDrawOverlays(this)) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return
        }
        val mpm = getSystemService(MediaProjectionManager::class.java)
        startActivityForResult(mpm.createScreenCaptureIntent(), 1)
    }

    override fun onActivityResult(rq: Int, rs: Int, d: Intent?) {
        if (rs == RESULT_OK && d != null) {
            startForegroundService(Intent(this, AssistService::class.java).putExtra("code", rs).putExtra("data", d))
            moveTaskToBack(true)
        }
    }
}
