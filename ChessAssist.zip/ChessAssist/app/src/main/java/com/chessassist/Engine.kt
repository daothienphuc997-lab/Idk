package com.chessassist

import android.content.Context
import java.io.File

/** Chạy Stockfish (file libstockfish.so trong jniLibs) qua giao thức UCI. */
class Engine(ctx: Context) {
    private val proc = ProcessBuilder(File(ctx.applicationInfo.nativeLibraryDir, "libstockfish.so").path)
        .redirectErrorStream(true).start()
    private val w = proc.outputStream.bufferedWriter()
    private val r = proc.inputStream.bufferedReader()

    private fun send(s: String) { w.write(s + "\n"); w.flush() }

    init {
        send("uci")
        while (r.readLine()?.startsWith("uciok") == false) { }
    }

    @Synchronized
    fun best(fen: String, ms: Int = 700): String? {
        send("position fen $fen")
        send("go movetime $ms")
        while (true) {
            val l = r.readLine() ?: return null
            if (l.startsWith("bestmove")) {
                val mv = l.split(" ").getOrNull(1) ?: return null
                return if (mv.length >= 4 && mv[0] in 'a'..'h') mv else null
            }
        }
    }

    fun close() { proc.destroy() }
}
