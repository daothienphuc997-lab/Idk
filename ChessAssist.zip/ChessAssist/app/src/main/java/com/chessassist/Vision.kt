package com.chessassist

import android.graphics.Bitmap
import kotlin.math.abs

/** Đọc bàn cờ bằng cách so hình dạng quân (mask) với mẫu học từ thế cờ ban đầu. */
class Vision {
    private val n = 24
    private val m = 3
    private val tpl = HashMap<Char, MutableList<BooleanArray>>()
    val calibrated get() = tpl.isNotEmpty()

    private class Sq(val mask: BooleanArray, val cover: Float, val lum: Float)

    private fun scan(b: Bitmap, x0: Float, y0: Float, sz: Float): Sq {
        val px = IntArray(n * n) {
            val i = it % n; val j = it / n
            b.getPixel((x0 + (i + .5f) * sz / n).toInt().coerceIn(0, b.width - 1),
                       (y0 + (j + .5f) * sz / n).toInt().coerceIn(0, b.height - 1))
        }
        val ring = ArrayList<Int>()
        for (k in m until n - m) { ring += px[m * n + k]; ring += px[(n - m - 1) * n + k]; ring += px[k * n + m]; ring += px[k * n + n - m - 1] }
        fun med(sh: Int) = ring.map { (it shr sh) and 255 }.sorted()[ring.size / 2]
        val br = med(16); val bg = med(8); val bb = med(0)
        val mask = BooleanArray(n * n)
        var cnt = 0; var tot = 0; var lum = 0f
        for (j in m until n - m) for (i in m until n - m) {
            val c = px[j * n + i]
            val r = (c shr 16) and 255; val g = (c shr 8) and 255; val bl = c and 255
            if (abs(r - br) + abs(g - bg) + abs(bl - bb) > 70) { mask[j * n + i] = true; cnt++; lum += 0.3f * r + 0.59f * g + 0.11f * bl }
            tot++
        }
        return Sq(mask, cnt.toFloat() / tot, if (cnt > 0) lum / cnt else 0f)
    }

    private fun iou(a: BooleanArray, b: BooleanArray): Float {
        var i = 0; var u = 0
        for (k in a.indices) { if (a[k] && b[k]) i++; if (a[k] || b[k]) u++ }
        return if (u == 0) 0f else i.toFloat() / u
    }

    /** Gọi khi màn hình đang là thế cờ ban đầu. */
    fun calibrate(b: Bitmap, flip: Boolean) {
        tpl.clear()
        val s = b.width / 8f
        val back = "rnbqkbnr"
        for (row in 0..7) for (col in 0..7) {
            val f = if (flip) 7 - col else col
            val r = if (flip) row else 7 - row
            val t = if (r == 0 || r == 7) back[f] else if (r == 1 || r == 6) 'p' else null
            if (t != null) tpl.getOrPut(t) { ArrayList() }.add(scan(b, col * s, row * s, s).mask)
        }
    }

    private fun classify(q: Sq): Char? {
        if (q.cover < 0.05f) return null
        var best = 'p'; var bs = -1f
        for ((t, list) in tpl) for (mk in list) { val v = iou(q.mask, mk); if (v > bs) { bs = v; best = t } }
        return if (q.lum > 140f) best.uppercaseChar() else best
    }

    /** Trả về phần vị trí quân của FEN (xoay 180° nếu đang lật bàn). */
    fun fen(b: Bitmap, flip: Boolean): String {
        val s = b.width / 8f
        val sb = StringBuilder()
        for (r in 0..7) {
            val row = if (flip) 7 - r else r
            var e = 0
            for (c in 0..7) {
                val col = if (flip) 7 - c else c
                val p = classify(scan(b, col * s, row * s, s))
                if (p == null) e++ else { if (e > 0) { sb.append(e); e = 0 }; sb.append(p) }
            }
            if (e > 0) sb.append(e)
            if (r < 7) sb.append('/')
        }
        return sb.toString()
    }
}
