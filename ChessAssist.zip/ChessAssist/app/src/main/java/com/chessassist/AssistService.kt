package com.chessassist

import android.app.*
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.*
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.WindowManager.LayoutParams as LP
import android.widget.Button
import android.widget.LinearLayout
import android.widget.Toast

class AssistService : Service() {
    private lateinit var wm: WindowManager
    private val ui = Handler(Looper.getMainLooper())
    private val worker = HandlerThread("work").apply { start() }
    private val work = Handler(worker.looper)
    private val lock = Any()
    private var buf: Bitmap? = null
    private var proj: MediaProjection? = null
    private val vision = Vision()
    private var engine: Engine? = null
    private lateinit var frame: FrameView
    private lateinit var arrow: ArrowView
    private lateinit var panel: LinearLayout
    private lateinit var frameLp: LP
    private var flip = false
    private var live = false
    private var lastFen = ""
    private var lastMove: String? = null

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("chess", "Chess Assist", NotificationManager.IMPORTANCE_LOW))
        startForeground(1, Notification.Builder(this, "chess").setContentTitle("Chess Assist đang chạy")
            .setSmallIcon(android.R.drawable.ic_menu_view).build(), ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        wm = getSystemService(WindowManager::class.java)
        val data = intent!!.getParcelableExtra<Intent>("data")!!
        proj = getSystemService(MediaProjectionManager::class.java).getMediaProjection(intent.getIntExtra("code", 0), data)
        proj!!.registerCallback(object : MediaProjection.Callback() { override fun onStop() { stopSelf() } }, ui)
        startCapture()
        buildOverlay()
        try { engine = Engine(this) } catch (e: Exception) { toast("Thiếu libstockfish.so: ${e.message}") }
        return START_NOT_STICKY
    }

    private fun startCapture() {
        val b = wm.maximumWindowMetrics.bounds
        val w = b.width(); val h = b.height()
        val reader = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2)
        val t = HandlerThread("cap").apply { start() }
        reader.setOnImageAvailableListener({ rd ->
            rd.acquireLatestImage()?.use { img ->
                val p = img.planes[0]
                synchronized(lock) {
                    val bw = p.rowStride / p.pixelStride
                    if (buf == null || buf!!.width != bw) buf = Bitmap.createBitmap(bw, h, Bitmap.Config.ARGB_8888)
                    p.buffer.rewind()
                    buf!!.copyPixelsFromBuffer(p.buffer)
                }
            }
        }, Handler(t.looper))
        proj!!.createVirtualDisplay("cap", w, h, resources.displayMetrics.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader.surface, null, null)
    }

    private fun lp(w: Int, h: Int, touch: Boolean) = LP(w, h, LP.TYPE_APPLICATION_OVERLAY,
        LP.FLAG_NOT_FOCUSABLE or LP.FLAG_LAYOUT_IN_SCREEN or LP.FLAG_LAYOUT_NO_LIMITS or (if (touch) 0 else LP.FLAG_NOT_TOUCHABLE),
        PixelFormat.TRANSLUCENT).apply { gravity = Gravity.TOP or Gravity.START }

    private fun buildOverlay() {
        val b = wm.maximumWindowMetrics.bounds
        arrow = ArrowView(this)
        wm.addView(arrow, lp(-1, -1, false))
        frameLp = lp(b.width(), b.width(), false).apply { x = 0; y = b.height() / 4 }
        frame = FrameView(this, wm, frameLp)
        wm.addView(frame, frameLp)
        panel = LinearLayout(this).apply { setBackgroundColor(0xAA000000.toInt()) }
        fun btn(t: String, a: () -> Unit) = Button(this).apply {
            text = t; textSize = 11f; isAllCaps = false; minWidth = 0; minimumWidth = 0
            setOnClickListener { a() }
        }.also { panel.addView(it) }
        btn("Dời") { frameLp.flags = frameLp.flags xor LP.FLAG_NOT_TOUCHABLE; wm.updateViewLayout(frame, frameLp); frame.invalidate() }
        btn("Học") { learn() }
        btn("Lật") { flip = !flip; toast(if (flip) "Bạn cầm quân đen (đen ở dưới)" else "Bạn cầm quân trắng (trắng ở dưới)") }
        btn("Gợi ý") { analyze() }
        btn("Live") { live = !live; toast(if (live) "Live bật" else "Live tắt"); ui.post(tick) }
        btn("X") { stopSelf() }
        val pl = lp(-2, -2, true).apply { gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL; y = 60 }
        wm.addView(panel, pl)
    }

    private val tick = object : Runnable {
        override fun run() { if (live) { analyze(); ui.postDelayed(this, 1500) } }
    }

    private fun crop(): Bitmap? = synchronized(lock) {
        val b = buf ?: return null
        val s = minOf(frameLp.width, b.width, b.height)
        Bitmap.createBitmap(b, frameLp.x.coerceIn(0, b.width - s), frameLp.y.coerceIn(0, b.height - s), s, s)
    }

    private fun learn() = work.post {
        val bmp = crop()
        if (bmp == null) toast("Chưa có hình màn hình") else { vision.calibrate(bmp, flip); toast("Đã học bàn cờ") }
    }

    private fun analyze() = work.post {
        if (!vision.calibrated) { toast("Bấm Học ở thế cờ ban đầu trước"); return@post }
        ui.post { arrow.set(null) }
        Thread.sleep(250)
        val bmp = crop() ?: return@post
        val fen = vision.fen(bmp, flip) + (if (flip) " b" else " w") + " - - 0 1"
        if (fen != lastFen || lastMove == null) { lastFen = fen; lastMove = engine?.best(fen) }
        val mv = lastMove
        ui.post { arrow.set(mv?.let { arrowPts(it) }) }
    }

    private fun pt(f: Int, r: Int): Pair<Float, Float> {
        val col = if (flip) 7 - f else f
        val row = if (flip) r else 7 - r
        val s = frameLp.width / 8f
        return Pair(frameLp.x + (col + .5f) * s, frameLp.y + (row + .5f) * s)
    }

    private fun arrowPts(m: String): FloatArray {
        val a = pt(m[0] - 'a', m[1] - '1'); val b = pt(m[2] - 'a', m[3] - '1')
        return floatArrayOf(a.first, a.second, b.first, b.second)
    }

    private fun toast(t: String) { ui.post { Toast.makeText(this, t, Toast.LENGTH_SHORT).show() } }

    override fun onDestroy() {
        live = false
        for (v in listOf<View>(arrow, frame, panel)) try { wm.removeView(v) } catch (_: Exception) {}
        engine?.close(); proj?.stop()
        super.onDestroy()
    }
}
