package com.chessassist

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager

class ArrowView(c: Context) : View(c) {
    private var a: FloatArray? = null
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xCC00C853.toInt(); strokeWidth = 18f; style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND }
    private val dot = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xCC00C853.toInt() }
    fun set(v: FloatArray?) { a = v; invalidate() }
    override fun onDraw(c: Canvas) {
        val v = a ?: return
        c.drawLine(v[0], v[1], v[2], v[3], line)
        c.drawCircle(v[2], v[3], 28f, dot)
    }
}

/** Khung chọn bàn cờ: kéo để di chuyển, kéo góc dưới-phải để đổi kích thước (khi bật Dời). */
class FrameView(c: Context, private val wm: WindowManager, private val lp: WindowManager.LayoutParams) : View(c) {
    private val p = Paint().apply { style = Paint.Style.STROKE; strokeWidth = 6f; color = 0xFF00E5FF.toInt() }
    private val h = Paint().apply { color = 0xFF00E5FF.toInt() }
    private var lx = 0f; private var ly = 0f; private var resize = false

    override fun onDraw(c: Canvas) {
        c.drawRect(3f, 3f, width - 3f, height - 3f, p)
        if ((lp.flags and WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE) == 0)
            c.drawRect(width * .85f, height * .85f, width.toFloat(), height.toFloat(), h)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.action) {
            MotionEvent.ACTION_DOWN -> { lx = e.rawX; ly = e.rawY; resize = e.x > width * .8f && e.y > height * .8f }
            MotionEvent.ACTION_MOVE -> {
                val dx = (e.rawX - lx).toInt(); val dy = (e.rawY - ly).toInt()
                lx = e.rawX; ly = e.rawY
                if (resize) { lp.width = (lp.width + dx).coerceAtLeast(200); lp.height = lp.width } else { lp.x += dx; lp.y += dy }
                wm.updateViewLayout(this, lp)
            }
        }
        return true
    }
}
