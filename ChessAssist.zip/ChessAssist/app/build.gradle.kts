plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android {
    namespace = "com.chessassist"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.chessassist"
        minSdk = 30; targetSdk = 34; versionCode = 1; versionName = "1.0"
        ndk { abiFilters += "arm64-v8a" }
    }
    packaging { jniLibs { useLegacyPackaging = true } }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
}
